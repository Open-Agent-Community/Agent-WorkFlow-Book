import unittest
from app import answer
class Tests(unittest.TestCase):
    def test_citation(self):self.assertEqual(answer('报销')['sources'],['policy-v1'])
    def test_permission(self):self.assertEqual(answer('预算','staff')['status'],'no_answer')
    def test_manager(self):self.assertEqual(answer('预算','manager')['sources'],['budget-v1'])
    def test_unknown(self):self.assertEqual(answer('工资')['status'],'no_answer')
    def test_invalid_role(self):self.assertEqual(answer('预算','admin')['status'],'denied')
    def test_version_and_rollback(self):
        self.assertIn('用途说明',answer('报销',version='v2')['answer'])
        self.assertNotIn('用途说明',answer('报销',version='v1')['answer'])
if __name__=='__main__':unittest.main()
