"""教学用权限检索基线。仅绑定本机；角色模拟不是真实鉴权，不调用大模型。"""
import json, os, time
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer
DOCS=json.loads(Path(__file__).with_name('docs.json').read_text())
def answer(question, role='staff', version='v1'):
    if role not in ('staff','manager'): return {'status':'denied','answer':'无效角色','sources':[]}
    allowed=[d for d in DOCS if role in d['roles'] and d['version']==version]
    matches=[d for d in allowed if any(k in question for k in d['keywords'])]
    if not matches:return {'status':'no_answer','answer':'授权资料中没有依据，请转人工确认。','sources':[]}
    d=matches[0];return {'status':'answered','answer':d['text'],'sources':[d['id']]}
class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path!='/ask':self.send_error(404);return
        size=int(self.headers.get('Content-Length','0'))
        if size>4096:self.send_error(413);return
        start=time.monotonic()
        try:
            data=json.loads(self.rfile.read(size));q=data['question'];role=data.get('role','staff')
            if not isinstance(q,str) or not q.strip():raise ValueError()
            out=answer(q,role,os.getenv('DOC_VERSION','v1'))
        except (KeyError,ValueError,TypeError):self.send_error(400);return
        # 不写入问题或资料正文，只记录状态与时延。
        with Path(__file__).with_name('events.jsonl').open('a') as f:f.write(json.dumps({'status':out['status'],'latency_ms':round((time.monotonic()-start)*1000,2)})+'\n')
        b=json.dumps(out,ensure_ascii=False).encode();self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
if __name__=='__main__':HTTPServer(('127.0.0.1',8765),Handler).serve_forever()
